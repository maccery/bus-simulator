//
// Created by Tom Macmichael on 18/12/2015.
//

#ifndef CSLP_TESTS_H
#define CSLP_TESTS_H



int errors;


void runTests();
#endif //CSLP_TESTS_H
